# CodeConvert.ai - visual feature reference

Captured: **21 October 2026**

**57 original website screenshots** | **8 public tools** | **desktop coverage**

Captured on 21 October 2026 from the desktop website. All eight public tool interfaces are included. The signed-in workspace was not entered; its preview and account capabilities are labeled as publicly advertised. One source-language directory and one language-pair page represent the repeated language templates. Mobile layouts were not captured.

## Public tools

| Tool | Visible features | Validation | Screenshot numbers |
|---|---|---|---|
| [Code Converter](https://www.codeconvert.ai/free-converter) | Source and destination selectors; code/file input; extra instructions; expanded editors; translated code and execution tabs; sharing, copying and downloading. | Live Python-to-JavaScript conversion succeeded; converted program executed. | 06-10 |
| [Code Generator](https://www.codeconvert.ai/free-code-generator) | Natural-language request; output language; expanded prompt/editor; generated code; execution, sharing, copy and download controls. | Live request produced a Python squares function. | 11-12, 52 |
| [Code Explainer](https://www.codeconvert.ai/free-code-explainer) | Language and code/file input; extra instructions; formatted explanation; expanded reading view; Markdown copy/download. | Live explanation returned headings, examples and improvement notes. | 13-14, 53, 56 |
| [Code Checker](https://www.codeconvert.ai/free-code-checker) | Language and code/file input; review instructions; issue descriptions; original/fixed snippets; full corrected code; expanded Markdown output. | Live review identified division by zero for an empty list. | 15-16, 54, 57 |
| [Code Fixer](https://www.codeconvert.ai/free-code-fixer) | Broken code plus optional error context; inline diff and plain code views; execution tab; change summary; expanded panels and output controls. | Live repair added a missing loop colon and displayed the change. | 17-18, 50-51 |
| [Comment Remover](https://www.codeconvert.ai/free-code-comment-remover) | Language and code/file input; cleaned code output; expanded editors; result sharing, copying and downloading. | Live request removed full-line and inline comments. | 19-20, 55 |
| [Code to PDF](https://www.codeconvert.ai/free-code-to-pdf) | 50,000-character counter; file upload; five font sizes; light/dark themes; five margins; line-number/title switches; document title; browser-print export. | Formatting controls verified with a dark theme and custom title; print export was not executed. | 21-22, 49 |
| [Code Runner](https://www.codeconvert.ai/code-runner) | Searchable Python/JavaScript/C/C++/Java selector; code editor; isolated execution; standard output/errors, status and elapsed time; repeat run. | Python and converted JavaScript each executed successfully in public tools. | 23-26, 10 |

## Shared interface features

- Paired editors with syntax colors, line numbers, upload affordances, expansion controls and a clear action appear across the code tools. Result actions vary by tool and output type.
- Public AI tools displayed two free uses per day. The converter FAQ lists a 4,000-character anonymous conversion limit. A free account is advertised with five extra credits and a 25,000-character limit.
- Completed results expose a share control. Explanation and review results expose Markdown copy/download actions; code outputs expose code copy/download actions. These controls were inspected visually.
- Public execution supports five languages, up to 10,000 source characters, standard-library programs and a three-run daily allowance. Network access, package installation and interactive stdin are unavailable according to the runner page.

## Website pages and appearance

- Homepage: centered headline and calls to action, moving language-logo strip, tool cards, workspace promotional image, access/privacy cards and a closing call to action. The homepage advertises 62 languages and seven focused tools; its public Free Tools menu contains eight entries.
- Navigation: logo/home, eight-tool dropdown, FAQs, pricing, contact and login. Footer includes tool/resource/legal groups, an affiliate link and an English/French selector on the homepage.
- Discovery: source-language cards and dedicated language-pair converters, including code examples and related tools. Python directory and Python-to-JavaScript page were captured as representative layouts.
- Help and support: collapsed and fully expanded FAQ pages; email/message contact form; direct support email link.
- Policy pages: Code Privacy, Privacy Policy and Terms, with legal navigation and section links.
- Visual direction: warm beige marketing background, white rounded cards, green primary controls, black headings, Geist sans-serif typography and language logos. The signed-out login uses a white background.

## Login and signed-in capabilities

**Observed login screen:** Google, GitHub and email one-time-code options, with a human-verification control. No authenticated workspace session was available.

**Advertised, not directly tested:** workspace navigation; pinned/popular tools; files and session history; AI follow-up chat; account and billing management; model/Standard/Advanced choices; file/ZIP context; cloud or local-only history controls. The public policy describes history deletion, uploaded-file visibility/deletion and an internal-evaluation opt-out. The workspace image in screenshot 05 is a marketing preview.

The FAQ describes more than 70 context-file types and automatic exclusion of common build/dependency folders from ZIP uploads. The policy describes default zero-retention routing with marked exceptions for some Advanced models. These are website statements, not an independent verification of provider behavior.

## Public pricing observed

| Plan | Monthly billing | Yearly billing | Usage | Characters/request | Context storage |
|---|---|---|---|---|---|
| Free account | $0 | $0 | 5 credits | 25,000 | Not listed |
| Pro | $19/month | $120/year ($10/month) | Unlimited Standard; 50 Advanced/month | 25,000 | 100 files |
| Premium | $39/month | $240/year ($20/month) | Unlimited Standard; 200 Advanced/month | 100,000 | 250 files |

Paid plan cards also list streamed responses, AI chat, priority support, cancellation and a 14-day refund guarantee. Prices exclude applicable tax. These values reflect the captured pricing page, not a purchase quote.

## Coverage and limits

- Six public AI workflows produced real example results: conversion, generation, explanation, checking, fixing and comment removal.
- Two sandbox executions succeeded: Python in the runner and JavaScript from the converter. Execution quotas were shared across the observed public runs.
- PDF options were configured; a PDF export from the website was not generated. Copy/download/share controls and the contact form were inspected, not submitted.
- Authenticated settings, billing, file management, history and AI-chat interactions remain unverified. No account was created and no paid plan was purchased.
- The screenshot book contains the 38 viewport captures. Full-page JPEGs are included in the ZIP and offline gallery at their original dimensions.

## Source pages

- https://app.codeconvert.ai/login
- https://www.codeconvert.ai/
- https://www.codeconvert.ai/code-privacy
- https://www.codeconvert.ai/code-runner
- https://www.codeconvert.ai/contact
- https://www.codeconvert.ai/convert-from-python
- https://www.codeconvert.ai/faqs
- https://www.codeconvert.ai/free-code-checker
- https://www.codeconvert.ai/free-code-comment-remover
- https://www.codeconvert.ai/free-code-explainer
- https://www.codeconvert.ai/free-code-fixer
- https://www.codeconvert.ai/free-code-generator
- https://www.codeconvert.ai/free-code-to-pdf
- https://www.codeconvert.ai/free-converter
- https://www.codeconvert.ai/pricing
- https://www.codeconvert.ai/privacy
- https://www.codeconvert.ai/python-to-javascript-converter
- https://www.codeconvert.ai/terms
