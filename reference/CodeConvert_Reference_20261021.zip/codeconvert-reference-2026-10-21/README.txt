CODECONVERT.AI SCREENSHOT COLLECTION
Captured 21 October 2026

1. Extract this ZIP.
2. Open index.html in your browser for the searchable offline gallery.
3. Open screenshots/ for all 57 original JPEG images.
4. Read feature-inventory.md for features, tested examples and coverage limits.
5. screenshot-index.csv maps images to source URLs and dimensions.
6. The PDF is a convenient book of the 38 viewport screenshots.

The authenticated application requires sign-in and is not directly captured.
The workspace image is a public marketing preview. Repeated language pages
are represented by the Python directory and Python-to-JavaScript converter.
